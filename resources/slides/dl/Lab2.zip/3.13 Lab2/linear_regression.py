import numpy as np
import random

def load_data(filename):
    """载入数据"""
    xys = []
    with open(filename, 'r') as f:
        for line in f:
            xys.append(list(map(float, line.strip().split())))

    if 'train' in filename:
        xs, ys = zip(*xys)
        return np.asarray(xs), np.asarray(ys)
    else:
        xs = [list(x)[0] for x in xys]
        return np.asarray(xs), None

class LinearRegression(object):
    def __init__(self):
        super(LinearRegression, self).__init__()
        '''
        self.w --> (2, ) is the parameter of a linear regression
        self.lr is the learning rate of training
        self.epoch is the iteration time of training
        '''
        self.w = 0.05 * np.random.randn(2)
        self.lr = 0.001
        self.epoch = 1000

    def predict(self, x):
        # 构造特征矩阵 [x, 1]
        feat_1 = np.expand_dims(x, axis=1)
        feat_0 = np.expand_dims(np.ones_like(x), axis=1)
        X_mat = np.concatenate([feat_1, feat_0], axis=1)

        y_pred = np.dot(X_mat, self.w)
        return y_pred
 
    def LSE(self, x, y):
        '''
        x and y are the data for estimate a linear regression
        '''
        # ==========
        # todo '''使用最小二乘法对self.w进行估计'''
        
        
        # ==========

class PolynomialRegression(object):
    def __init__(self):
        # 初始化权重：w2, w1, w0
        self.w = 0.05 * np.random.randn(3)
        self.lr = 1e-6
        self.epoch = 1000

    def predict(self, x):
        # 构造特征矩阵 [x^2, x, 1]
        feat_2 = np.expand_dims(x**2, axis=1)
        feat_1 = np.expand_dims(x, axis=1)
        feat_0 = np.ones_like(feat_1)
        X_mat = np.concatenate([feat_2, feat_1, feat_0], axis=1)
        
        return np.dot(X_mat, self.w)

    def train(self, x, y):
        """
        x and y are the data for estimate a polynomial regression
        """
        # ==========
        # todo '''使用随机梯度下降法  训练一元二次回归模型'''
        
        
        # ==========

def evaluate(ys, ys_pred):
    """评估模型。"""
    std = np.sqrt(np.mean(np.abs(ys - ys_pred) ** 2))
    return std

if __name__ == '__main__':
    solver = 'GD'
    train_file = './input/train.txt'
    test_file = './input/test_X.txt'
    
    # 载入数据
    x_train, y_train = load_data(train_file)
    x_test, _ = load_data(test_file)

    
    if solver == 'GD':
        f = PolynomialRegression()
        f.train(x_train, y_train)
    elif solver == 'LSE':
        f = LinearRegression()
        f.LSE(x_train, y_train)
    else:
        raise TypeError("Wrong solver !")
        
    y_train_pred = f.predict(x_train)
    std = evaluate(y_train, y_train_pred)
    print('The std on training data is ：{:f}'.format(std))

    preds = f.predict(x_test)
    # 确保输出目录存在
    import os
    if not os.path.exists('./output'):
        os.makedirs('./output')
    np.save('./output/predict', preds)