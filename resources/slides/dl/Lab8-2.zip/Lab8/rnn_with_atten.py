import torch
from torch import nn


class Sequence_Modeling(nn.Module):
    def __init__(self, vocab_size, embedding_size, num_outputs, hidden_size):
        super(Sequence_Modeling, self).__init__()
        self.emb_layer = nn.Embedding(vocab_size, embedding_size)
        self.encoder = nn.RNN(embedding_size, hidden_size, batch_first=True)

        self.decoder = nn.RNN(embedding_size+hidden_size, hidden_size, batch_first=True)
        self.softmax = nn.Softmax(dim=2)
        self.linear = nn.Linear(hidden_size, num_outputs)

    def encode(self, enc_x, state):
        enc_emb = self.emb_layer(enc_x)
        enc_hidden, state = self.encoder(enc_emb, state)

        return enc_hidden, state

    def decode(self, dec_y, enc_hidden, state, is_train = True):
        dec_embs = self.emb_layer(dec_y)
        trg_len = dec_y.shape[1]
        outputs = []
        state = state.transpose(1, 0)

        for t in range(trg_len):
            scores = torch.bmm(state, enc_hidden.transpose(2, 1))
            
            # 计算attention weights
            alpha = self.softmax(scores)  # (batch_size, 1, seq_len)

            # 计算context vector
            cont_vec = torch.bmm(alpha, enc_hidden).squeeze(1)
            input_vec = torch.cat([cont_vec, dec_embs[:, t, :]], 1).unsqueeze(1)
            sent_hidden, state = self.decoder(input_vec, state.transpose(0, 1))
            state = state.transpose(0, 1)

            # 输出预测字符
            pred = self.linear(sent_hidden)
            outputs += [pred]

        sent_outputs = torch.cat(outputs, dim = 1)

        return sent_outputs, state

    def predict_with_pointer_network(self, enc_x, state):
        output = [0] 

        '''
        enc_x --> (B, S), where B = batch_size, S = sequence length
        state --> (1, B, H), where B = batch_size, H = hidden_size
        请把原decode解码器改成将注意力机制作为pointer network的解码过程，即：不使用self.linear()完成解码
        其中打分函数使用点积模型

        输出：
        排除掉第一个位置的解码序列：output的大小应为(B, S, O) where O = num_outputs, 
        最后一个时刻隐藏状态：state的大小应为(1, B, H)
        '''
        
        # ==========
        # todo '''请补全代码'''
        # ==========

        pass



if __name__ == '__main__':
    model = Sequence_Modeling(vocab_size=28, embedding_size=100, num_outputs=28, hidden_size=100)