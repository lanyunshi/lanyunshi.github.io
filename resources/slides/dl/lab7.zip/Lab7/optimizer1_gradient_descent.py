import numpy as np
import torch
import math
import d2lzh_pytorch as d2l
from matplotlib import pyplot as plt

def gd(eta):
    # gradient descent algorithm
    x = 10
    results = [x]
    for i in range(10):
        x -= eta * 2 * x  # f(x) = x * x的导数为f'(x) = 2 * x
        results.append(x)
        print('epoch %s, x: %s' %(i, x))
    return results, eta

def show_trace(res):
    res, eta = res
    n = max(abs(min(res)), abs(max(res)), 10)
    f_line = np.arange(-n, n, 0.1)
    d2l.set_figsize()
    d2l.plt.plot(f_line, [x * x for x in f_line])
    d2l.plt.plot(res, [x * x for x in res], '-o')
    plt.title('Learning rate %f' %eta)
    d2l.plt.xlabel('x')
    d2l.plt.ylabel('f(x)')
    plt.show()

def train_2d(trainer, eta):
    x1, x2 = -5, -2
    results = [(x1, x2)]
    for i in range(20):
        x1, x2, eta = trainer(x1, x2, eta)
        results.append((x1, x2))
        print('epoch %d, x1 %f, x2 %f' % (i + 1, x1, x2))
    return results, eta

def show_trace_2d(f, results):
    results, eta = results
    d2l.plt.plot(*zip(*results), '-o', color='#ff7f0e')
    x1, x2 = np.meshgrid(np.arange(-5.5, 1.0, 0.1), np.arange(-3.0, 1.0, 0.1))
    d2l.plt.contour(x1, x2, f(x1, x2), colors='#1f77b4')
    plt.title('Learning rate %f' %eta)
    d2l.plt.xlabel('x1')
    d2l.plt.ylabel('x2')
    plt.show()

def f_2d(x1, x2):  # 目标函数
    return x1 ** 2 + 2 * x2 ** 2

def gd_2d(x1, x2, eta):
    return x1 - eta * 2 * x1, x2 - eta * 4 * x2, eta

if __name__ == '__main__':
    # when the learning rate is 0.2
    show_trace(gd(0.1))

    # when the learning rate is 0.05
    show_trace(gd(0.01))

    # when the learning rate is 1.1
    show_trace(gd(1.1))

    # when it is the multi-dimension gradient dscient
    show_trace_2d(f_2d, train_2d(gd_2d, 0.1))
